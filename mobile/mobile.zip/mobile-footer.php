   <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

    <!-- <script src="../js/popper.min.js"></script> -->
    <script src="../js/bootstrap.min.js"></script>
    <script type="text/javascript">



    $('.btn').click(function(){
      playSound();
    });

    // <?php 

    // mysqli_close($connection);
    //  ?>


    </script>
  </body>
</html>