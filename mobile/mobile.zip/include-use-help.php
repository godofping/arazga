<?php 

include('../connection.php');

$_SESSION['coins'] -= 50;

 ?>

