<?php include('mobile-header.php'); 
if (!isset($_SESSION['playerId'])) {
  header("Location: mobile-login.php");
}

?>



    <div class="container-fluid">
      <div class="row mt-5">
        <div class="col-md-12">
          
          <div class="card">
            <div class="card-body">


              <h5 class="text-center">Leaderboard</h5>
               <hr>

                <div class="container">


                  <div class="row">
                    
                    <h6 class="text-center">Top 10 player with the highest score</h6>

                    <table class="table mt-3">
                      <thead class="thead-dark">
                        <tr>
                          <th scope="col" width="20%">Rank</th>
                          <th scope="col" width="60%">Username</th>
                          <th scope="col" width="20%">Total Score</th>
                        </tr>
                      </thead>
                      <tbody>

                        <?php $rank = 1; $qry = mysqli_query($connection, "SELECT SUM(score) AS 'Total Score', username  FROM solo_player_game_history_view GROUP BY playerId ORDER BY 'Total Score' ASC LIMIT 3"); while ($res = mysqli_fetch_assoc($qry)) {?>
                        <tr>
                          <th scope="row"><?php echo $rank; $rank++; ?></th>
                          <td><?php echo $res['username'] ?></td>
                          <td><?php echo $res['Total Score'] ?></td>
                        </tr>
                        <?php } ?>
                        
                      </tbody>
                    </table>

              
                  </div>

              
                  <div class="row mt-3 text-center">
                    <div class="col-md-12">
                      <a href="mobile-main-menu.php"><button type="button" class="btn btn-block btn-secondary">Back</button></a>
                    </div>
                  </div>


                  <hr>




   
                </div>

      
            </div>
          </div>

        </div>
      </div>
      
    </div>


 <?php include('mobile-footer.php') ?>
 

