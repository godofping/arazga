<?php

include("../connection.php");


if (isset($_POST['from']) and $_POST['from'] == 'mobile-register') {
	$qry = mysqli_query($connection, "select * from player_table where username = '" . $_POST['username'] . "'");
	if (mysqli_num_rows($qry) > 0) {
		header("Location: mobile-register.php?failed=username-taken&username=" . $_POST['username'] . "");
	}
	else
	{
		if ($_POST['password'] != $_POST['confirmPassword']) {
			header("Location: mobile-register.php?failed=password-not-match");
		}
		else
		{
			mysqli_query($connection, "insert into player_table (username, password) values ('" . $_POST['username'] . "', '" . $_POST['password'] . "')");

			$_SESSION['playerId'] = mysqli_insert_id($connection);

			$_SESSION['music'] ="music1";
			$_SESSION['sound'] ="sound1";
			$_SESSION['background'] = "background1";


			mysqli_query($connection, "insert into setting_table (playerId, music, sound, background) values ('" . $_SESSION['playerId'] . "', 'music1', 'sound1', 'background1')");

			
			header("Location: mobile-main-menu.php");
		}
		
	}
}

if (isset($_POST['from']) and $_POST['from'] == 'mobile-login') {
	$qry = mysqli_query($connection, "select * from player_table where username = '" . $_POST['username'] . "' and password = '" . $_POST['password'] . "'");
	if (mysqli_num_rows($qry) > 0) {

		$res = mysqli_fetch_assoc($qry);

		$_SESSION['playerId'] = $res['playerId'];



		$qry = mysqli_query($connection, "select * from setting_table where playerId = '" . $res['playerId'] . "'");
		$res = mysqli_fetch_assoc($qry);

		$_SESSION['music'] = $res['music'];
		$_SESSION['sound'] = $res['sound'];
		$_SESSION['background'] = $res['background'];

		header("Location: mobile-main-menu.php");

	}
	else
	{
		header("Location: mobile-login.php?failed=login");	
	}
}

if (isset($_GET['from']) and $_GET['from'] == 'mobile-logout') {
	session_destroy();
	header("Location: mobile-logout.php");
}




?>