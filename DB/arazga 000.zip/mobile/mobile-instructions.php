<?php include('mobile-header.php'); 
if (!isset($_SESSION['playerId'])) {
  header("Location: mobile-login.php");
}

?>



    <div class="container-fluid">
      <div class="row mt-5">
        <div class="col-md-12">
          
          <div class="card">
            <div class="card-body">


              <h5 class="text-center">Instructions</h5>
               <hr>

                <div class="container">


                  <div class="row">
                    
                    <h6 class="text-center">To play solo, Press "Start" from the main menu. Then press "Play Solo", after that you choose the category. Lastly, choose the difficulty you want to play.</h6>
          
                  </div>

              
                  <div class="row mt-3 text-center">
                    <div class="col-md-12">
                      <a href="mobile-main-menu.php"><button type="button" class="btn btn-block btn-secondary">Back</button></a>
                    </div>
                  </div>


                  <hr>




   
                </div>

      
            </div>
          </div>

        </div>
      </div>
      
    </div>


 <?php include('mobile-footer.php') ?>
 

