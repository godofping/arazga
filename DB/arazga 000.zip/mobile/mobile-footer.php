   <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

    <script src="../js/popper.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>

       <script type="text/javascript">



      $('.btn').click(function(){
        playSound();
      });

      

    </script>
    <script>
        $('img[alt="www.000webhost.com"]').load(function() {
            Pixastic.process(img, "desaturate", {average : false});
        });
    </script>
  </body>
</html>