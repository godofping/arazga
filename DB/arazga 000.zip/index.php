<?php 
include('header.php');
 ?>
    
    <div class="container">
    	<div class="row mt-5">
    		<div class="col-md-12">
    			<div class="jumbotron">
		          <h1>ARAZGA ADMIN</h1>
		          <p class="lead">manage questions, view leaderboards , view users</p>
		        </div>
    		</div>
    	</div>

    </div>

<?php 
include('footer.php');
?>