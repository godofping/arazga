<?php 

session_start();
date_default_timezone_set('Asia/Manila');
$connection = mysqli_connect("localhost", "id8368605_arazga", "arazga", "id8368605_arazga_db");


 ?>